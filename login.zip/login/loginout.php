<?php
     session_start();
     include"config.php";
     $name = $_POST['username'];
     $password = $_POST['password'];
     if($name == ''||$password ==''){
     	echo "<script> alert('请输入用户名或密码！');location.href = 'login.php';</script>";
          
     }else{
     	$sql = "select*from yonghu where name = '{$name}' and password = '{$password}'";
     	$query = mysqli_query($link,$sql);
     	$arr = mysqli_fetch_array($query);
     	if(!$arr){
     		echo "<script> alert('登录失败，请确认用户名或密码！');location.href = 'login.php';</script>";
           

     	}else{
           
            
               $_SESSION['name'] = $name;
            
     		echo "<script> alert('恭喜你，登录成功！');location.href = 'photo.php';</script>";
           
     	}
     }


mysqli_close($link);

?>