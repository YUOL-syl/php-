<?php
   
   $link = mysqli_connect('localhost','root','');
   mysqli_select_db($link,'sheying');
   mysqli_query($link,"set names utf8");
   //图片类型列表信息
   $typelist=array(1=>"体育",2=>"花海",3=>"生活",4=>"冰雪",5=>"萌宠",6=>"人像",7=>"纪实",8=>"风光",9=>"汽车",10=>"空山",11=>"性感",12=>"其他");
   header("content-type:text/html;charset=utf-8");




?>