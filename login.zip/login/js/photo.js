var div1 = document.querySelector('#div1');

document.onmouseover = function () {

// div1.style.left = '420px';

var a = true;

setInterval(function() {

div1.style.top = (a ? 0 : 20) + 'px';

a = !a;

}, 270);

}

	function showsubmenu(li) {
	var submenu=li.getElementsByTagName("ul")[0];
	submenu.style.display="block";
}
	function hidesubmenu(li) {
	var submenu=li.getElementsByTagName("ul")[0];
	submenu.style.display="none";
}