<?php
include"config.php";
session_start();
$name = $_POST['username'];
$password = $_POST['password'];
$dbpassword = $_POST['confirm_password'];
if($name == ''||$password ==''||$dbpassword ==''){
	echo "<script> alert('请输入完整信息！');location.href = 'register.php';</script>";
	
}else{
	  $sql = "select*from yonghu where name = '{$name}' ";
     	$query = mysqli_query($link,$sql);
     	$arr = mysqli_fetch_array($query);
     	if($arr){
     		echo "<script> alert('用户已存在！');location.href = 'register.php';</script>";
     		
     		exit();
     	}
	  if($password!=$dbpassword){
		echo "<script> alert('两次密码不一致！');location.href = 'register.php';</script>";
	
	}else{
		$sql = "insert into yonghu(name,password) values('{$name}','{$password}')";
		if(!mysqli_query($link,$sql)){
			echo "<script> alert('注册失败！');location.href = 'register.php';</script>";
			
		}else{
			echo "<script> alert('恭喜你，注册成功！');location.href = 'login.php';</script>";	
		
		}
	}

}


mysqli_close($link);
 ?>